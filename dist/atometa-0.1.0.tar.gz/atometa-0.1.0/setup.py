from setuptools import setup, Extension
import os
import sys
import glob

# Detect vcpkg installation
VCPKG_ROOT = os.environ.get('VCPKG_ROOT', 'C:/vcpkg')
VCPKG_TRIPLET = 'x64-windows'

# vcpkg include and lib paths
vcpkg_include = os.path.join(VCPKG_ROOT, 'installed', VCPKG_TRIPLET, 'include')
vcpkg_lib = os.path.join(VCPKG_ROOT, 'installed', VCPKG_TRIPLET, 'lib')

print(f"Using vcpkg at: {VCPKG_ROOT}")
print(f"Include path: {vcpkg_include}")
print(f"Library path: {vcpkg_lib}")

# Check if vcpkg paths exist
if not os.path.exists(vcpkg_include):
    print(f"WARNING: vcpkg include path not found: {vcpkg_include}")
    print("Install GLM with: vcpkg install glm:x64-windows")

# Compiler flags
extra_compile_args = []
extra_link_args = []

if sys.platform == 'win32':
    extra_compile_args = [
        '/std:c++17',
        '/EHsc',
        '/O2',           # Optimize for speed
        '/W3',           # Warning level 3
        '/MD',           # Multi-threaded DLL runtime
    ]
else:
    extra_compile_args = [
        '-std=c++17',
        '-O3',
        '-fPIC',
    ]

# Python extension module
atometa_module = Extension(
    'atometa',
    sources=[
        'src/python/PyAtometa.cpp',
        'src/core/Logger.cpp',
        'src/chemistry/Atom.cpp',
        'src/chemistry/PeriodicTable.cpp',
        'src/chemistry/Bond.cpp',
        'src/chemistry/Molecule.cpp',
        'src/chemistry/MolecularFileIO.cpp',
        'src/physics/ForceField.cpp',
        'src/physics/MolecularDynamics.cpp',
        'src/physics/EnergyMinimizer.cpp',
    ],
    include_dirs=[
        'include',
        vcpkg_include,
    ],
    library_dirs=[
        vcpkg_lib,
    ],
    libraries=[],  # Header-only libraries (GLM)
    extra_compile_args=extra_compile_args,
    extra_link_args=extra_link_args,
    language='c++',
)

setup(
    name='atometa',
    version='0.1.0',
    description='Molecular dynamics simulation Python bindings',
    long_description=open('README.md').read() if os.path.exists('README.md') else 
                     'Atometa - Molecular Dynamics Simulation Engine',
    long_description_content_type='text/markdown',
    author='Your Name',
    author_email='your.email@example.com',
    url='https://github.com/yourusername/atometa',
    ext_modules=[atometa_module],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Chemistry',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14',
    ],
    python_requires='>=3.8',
    install_requires=[
        'numpy>=1.20.0',
    ],
)