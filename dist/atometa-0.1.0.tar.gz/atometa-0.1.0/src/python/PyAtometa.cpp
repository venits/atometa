// src/python/PyAtometa.cpp

#include "Atometa/Python/PyAtometa.h"
#include <Python.h>
#include <string>
#include <glm/glm.hpp>  // لو مش مستخدم glm، احذفه

// Helper: Python list [x,y,z] → glm::vec3
static bool PyListToVec3(PyObject* py_list, glm::vec3& out) {
    if (!PyList_Check(py_list) || PyList_Size(py_list) != 3) {
        PyErr_SetString(PyExc_TypeError, "Expected list of 3 floats");
        return false;
    }
    for (int i = 0; i < 3; ++i) {
        PyObject* item = PyList_GetItem(py_list, i);
        if (!PyFloat_Check(item)) {
            PyErr_SetString(PyExc_TypeError, "Position must be floats");
            return false;
        }
        out[i] = static_cast<float>(PyFloat_AsDouble(item));
    }
    return true;
}

// ============================================================================
// Molecule functions (fully qualified)
// ============================================================================

PyObject* Atometa::Python::PyMolecule_New(PyTypeObject* type, PyObject* args, PyObject* kwds) {
    static char* kwlist[] = {"name", nullptr};
    const char* name = "Unnamed";
    if (!PyArg_ParseTupleAndKeywords(args, kwds, "|s", kwlist, &name)) {
        return nullptr;
    }

    Atometa::Python::PyMolecule* self = reinterpret_cast<Atometa::Python::PyMolecule*>(
        type->tp_alloc(type, 0)
    );
    if (!self) {
        return nullptr;
    }

    self->molecule = new Atometa::Molecule(std::string(name));
    return reinterpret_cast<PyObject*>(self);
}

void Atometa::Python::PyMolecule_Dealloc(Atometa::Python::PyMolecule* self) {
    delete self->molecule;
    Py_TYPE(self)->tp_free(reinterpret_cast<PyObject*>(self));
}

PyObject* Atometa::Python::PyMolecule_AddAtom(Atometa::Python::PyMolecule* self, PyObject* args) {
    const char* symbol = nullptr;
    PyObject* pos_list = nullptr;
    if (!PyArg_ParseTuple(args, "sO", &symbol, &pos_list)) {
        return nullptr;
    }

    glm::vec3 pos(0.0f);
    if (!PyListToVec3(pos_list, pos)) {
        return nullptr;
    }

    // افتراض أن add_atom ترجع Atom* أو index - غيّر حسب كلاسك الحقيقي
    Atometa::Atom* atom = self->molecule->add_atom(std::string(symbol), pos);
    long idx = atom ? static_cast<long>(atom->GetIndex()) : -1L;
    return PyLong_FromLong(idx);
}

PyObject* Atometa::Python::PyMolecule_AddBond(Atometa::Python::PyMolecule* self, PyObject* args) {
    unsigned long a = 0, b = 0;
    if (!PyArg_ParseTuple(args, "kk", &a, &b)) {
        return nullptr;
    }

    bool ok = self->molecule->add_bond(static_cast<uint32_t>(a), static_cast<uint32_t>(b));
    return PyBool_FromLong(ok ? 1 : 0);
}

PyObject* Atometa::Python::PyMolecule_GetFormula(Atometa::Python::PyMolecule* self, PyObject*) {
    return PyUnicode_FromString(self->molecule->formula.c_str());
}

PyObject* Atometa::Python::PyMolecule_Save(Atometa::Python::PyMolecule* self, PyObject* args) {
    const char* filename = nullptr;
    if (!PyArg_ParseTuple(args, "s", &filename)) {
        return nullptr;
    }

    bool ok = self->molecule->save(filename);
    return PyBool_FromLong(ok ? 1 : 0);
}

// ============================================================================
// Method table (MUST come before PyTypeObject)
// ============================================================================

static PyMethodDef PyMolecule_methods[] = {
    {"add_atom",    (PyCFunction)Atometa::Python::PyMolecule_AddAtom,   METH_VARARGS, "Add atom"},
    {"add_bond",    (PyCFunction)Atometa::Python::PyMolecule_AddBond,   METH_VARARGS, "Add bond"},
    {"get_formula", (PyCFunction)Atometa::Python::PyMolecule_GetFormula,METH_NOARGS,  "Get formula"},
    {"save",        (PyCFunction)Atometa::Python::PyMolecule_Save,      METH_VARARGS, "Save to file"},
    {nullptr, nullptr, 0, nullptr}
};

// ============================================================================
// PyTypeObject (old style - no designated initializers)
// ============================================================================

PyTypeObject Atometa::Python::PyMoleculeType = {
    PyVarObject_HEAD_INIT(NULL, 0)
};

// Initialize in module init
static void InitMoleculeType() {
    Atometa::Python::PyMoleculeType.tp_name      = "atometa.Molecule";
    Atometa::Python::PyMoleculeType.tp_basicsize = sizeof(Atometa::Python::PyMolecule);
    Atometa::Python::PyMoleculeType.tp_flags     = Py_TPFLAGS_DEFAULT;
    Atometa::Python::PyMoleculeType.tp_doc       = "Molecule object";
    Atometa::Python::PyMoleculeType.tp_methods   = PyMolecule_methods;
    Atometa::Python::PyMoleculeType.tp_new       = Atometa::Python::PyMolecule_New;
    Atometa::Python::PyMoleculeType.tp_dealloc   = (destructor)Atometa::Python::PyMolecule_Dealloc;
}

// ============================================================================
// Module
// ============================================================================

static PyMethodDef module_methods[] = {
    {nullptr, nullptr, 0, nullptr}
};

static struct PyModuleDef atometa_module = {
    PyModuleDef_HEAD_INIT,
    "atometa",
    "Atometa Molecular Engine",
    -1,
    module_methods
};

PyMODINIT_FUNC PyInit_atometa(void) {
    PyObject* m = nullptr;

    InitMoleculeType();

    if (PyType_Ready(&Atometa::Python::PyMoleculeType) < 0) {
        return nullptr;
    }

    m = PyModule_Create(&atometa_module);
    if (!m) {
        return nullptr;
    }

    Py_INCREF(&Atometa::Python::PyMoleculeType);
    if (PyModule_AddObject(m, "Molecule", (PyObject*)&Atometa::Python::PyMoleculeType) < 0) {
        Py_DECREF(&Atometa::Python::PyMoleculeType);
        Py_DECREF(m);
        return nullptr;
    }

    return m;
}